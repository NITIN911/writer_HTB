#!/usr/bin/env python3
import smtplib
host = '127.0.0.1'
port = 25
From = 'kyle@writer.htb'
To = 'john@writer.htb'
Message = '''\
Subject: HI THERE! JOHN
OOPS I GOT YOU MATE.
'''
try :
io = smtplib . SMTP ( host , port )
io . ehlo ( )
io . sendmail ( From , To , Message )
except Exceptions as e :
print ( e )
finally :
io . quit ( )
